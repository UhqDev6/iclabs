create view vw_jadwal as
select `iclabs`.`assistants`.`stambuk`  AS `stambuk`,
       `iclabs`.`assistants`.`name`     AS `name`,
       `iclabs`.`assistants`.`image`    AS `image`,
       `iclabs`.`status`.`status`       AS `status`,
       `iclabs`.`praktikum`.`praktikum` AS `praktikum`,
       `iclabs`.`ruangan`.`ruangan`     AS `ruangan`,
       `iclabs`.`jadwal`.`waktu`        AS `waktu`
from `iclabs`.`assistants`
         join `iclabs`.`praktikum`
         join `iclabs`.`ruangan`
         join `iclabs`.`status`
         join `iclabs`.`jadwal`
where `iclabs`.`jadwal`.`id` = `iclabs`.`assistants`.`id`
  and `iclabs`.`jadwal`.`id_praktikum` = `iclabs`.`praktikum`.`id_praktikum`
  and `iclabs`.`jadwal`.`id_ruangan` = `iclabs`.`ruangan`.`id_ruangan`
  and `iclabs`.`jadwal`.`id_status` = `iclabs`.`status`.`id_status`;

