create view vw_data as
select `iclabs`.`assistants`.`id`    AS `id`,
       `iclabs`.`assistants`.`name`  AS `name`,
       `iclabs`.`assistants`.`image` AS `image`,
       `iclabs`.`status`.`status`    AS `status`
from `iclabs`.`assistants`
         join `iclabs`.`status`
where `iclabs`.`status`.`id` = `iclabs`.`assistants`.`id`;

